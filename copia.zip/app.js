var createError = require('http-errors');
var express = require('express');
var path = require('path');

var cookieParser = require('cookie-parser');
var logger = require('morgan');
//const multer = require('multer');
var mongoose = require('mongoose');
var Resource = require('resourcejs');
var cors = require('cors')
 var bodyParser = require('body-parser');    
var phantomJsCloud = require("phantomjscloud");

var indexRouter = require('./routes/index');
var usersRouter = require('./routes/users');

var app = express();



mongoose.connect('mongodb://datosg:ccabreraq12@ds029901.mlab.com:29901/datosg');



// load the database models
const Firma_doc = require('./mongoose/doc-model')
const Puntos = require('./mongoose/puntos-model')
const Users = require('./mongoose/user-model')



// view engine setup
//app.set('views', path.join(__dirname, 'views'));
//app.set('view engine', 'jade');
// view engine setup
app.set('views', path.join(__dirname, 'views'));
//app.engine('html', require('ejs').renderFile);
//app.set('view engine', 'html');


app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

app.use('/', indexRouter);
app.use('/users', usersRouter);

// catch 404 and forward to error handler
//app.use(function(req, res, next) {
//  next(createError(404));
//});

// error handler
app.use(function(err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error');
});

app.use(bodyParser.urlencoded({extended: true}));
app.use(bodyParser.json());

app.use(cors({
			 //exposedHeaders: ['X-Total-Count', 3],

			}));


			
Resource(app, '', 'puntos', Puntos).rest();
Resource(app, '', 'users', Users).rest();
Resource(app, '', 'firma_doc', Firma_doc).rest();


async function gen_pdf(html) {

    var apiKey = 'ak-e1b1d-chnt0-ra0y7-yemfh-ahrdt'; //leave undefined to use a demo key.  get a free key at https://Dashboard.PhantomJsCloud.com

    var myPromise = () => {
       return new Promise((resolve, reject) => {

			var browser = new phantomJsCloud.BrowserApi(apiKey);
			
			   var pageRequest = { url:"https://b541addd946a.ngrok.io/index2.html", renderType: "pdf",renderSettings: {pdfOptions: {format: "onepage"}} };

			   //console.log("about to request page from PhantomJs Cloud.  request =", JSON.stringify(pageRequest, null, "\t"));
			browser.requestSingle(pageRequest, function (err, userResponse) {
				if (userResponse.statusCode != 200) {
					console.log(" errror invalid status code" + userResponse.statusCode);
					reject("err") 
					//return ("")
				} else {
					//console.log(userResponse.content)
					
				
					fs.writeFile("prueba1.pdf", userResponse.content.data, {
						encoding: userResponse.content.encoding,
                        //resolve("ok");	
						
					}, function (err) {
						console.log("captured page written to " + userResponse.content.name);
                        //resolve("erro");				
						
					});
					resolve(userResponse.content.data);

				}
			});
	   })
    };
	
   //var result = await myPromise();
   ////console.log(result)
   ////continue execution
   //return result;   
	
};



module.exports = app;
