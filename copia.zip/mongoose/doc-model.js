const mongoose = require('mongoose')

const { Schema } = mongoose

const DocSchema = new Schema({
  nombre: String,
  descripcion:  String ,
  otro: String,
  url:  String ,
  fecha_creacion:Date,
  status: String,
  hrml: String,
  parametros: []
})

const Firma_doc = mongoose.model('Firma_doc', DocSchema)

module.exports = Firma_doc