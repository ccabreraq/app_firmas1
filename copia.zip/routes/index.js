var express = require('express');
var router = express.Router();
const multer = require('multer');
var fs = require('fs');
var path = require('path');
 var bodyParser = require('body-parser');    

const storage = multer.diskStorage({
    destination:path.join(__dirname+'../public','/uploads'),
    filename:(req,file,cb)=>{
        //cb(null,file.originalname);
        cb(null,"usuario"+"_aa.pdf");
    }
});

var upload = multer({ storage: storage })
var upload1 = multer()


/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});

	router.post('/upload', upload.single('file'), (req, res) => {
	  if (!req.file.mimetype.startsWith('application/*')) {
		  console.log(req.file)
		//return res.status(422).json({
		//  error :'El archivo debe ser PDF'
		//});
	  }

	  //const dimensions = sizeOf(req.file.path);
	  //
	  //if ((dimensions.width < 640) || (dimensions.height < 480)) {
	  //  return res.status(422).json({
	//	  error :'The image must be at least 640 x 480px'
	//	});
	//  }
	 //
	  return res.status(200).send(req.file);
	});
	
	router.post('/firmantes',bodyParser.json(), function (req, res, next) {
		console.log(req.body);
		
		gen_pdf(req.body.html)
		
		//dbxx2.collection('firma_doc').insert(req.body, function(err, newDoc) {
		//    if (newDoc !== null) {                        
		//        return res.status(200).send();
		//    } else {
		//        return res.status(500).send("error");
		//    }
		//});
		
		
	  // req.body contains the text fields
	  //return res.status(200).send();
	})			
	

	router.get("/get/a", function(req, res){
		console.log(req);
		res.send("GET res sent from webpack dev server")
	})

	router.post("/post/a", bodyParser.json(), function(req, res){
		console.log(req.body);
		res.send("POST res sent from webpack dev server")
	})
			


module.exports = router;
